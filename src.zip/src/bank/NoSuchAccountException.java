
package bank;

public class NoSuchAccountException extends Exception {
    NoSuchAccountException(String msg) {
        super(msg);
    }
}

